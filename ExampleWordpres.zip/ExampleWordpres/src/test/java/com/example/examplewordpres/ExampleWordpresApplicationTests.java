package com.example.examplewordpres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleWordpresApplicationTests {

    @Test
    void contextLoads() {
    }

}
